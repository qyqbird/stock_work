# -*- coding: utf-8 -*-
# @Author: yuqing5

from pandas import *

obj = Series([4,7,-5,3], index=['d','a','b','c'])
print obj
print obj.index
print obj.values